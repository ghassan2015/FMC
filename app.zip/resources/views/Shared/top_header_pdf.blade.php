<div style="text-align: center; font-family:'XBRiyaz', serif;">
    <table width="100%" style="border: none; font-size: 12px;">
        <tr>
            <td style="width: 30%; text-align: center;">
                <div style="font-size: 14px; font-weight: bold;">
                    دولة فلسطين<br>
                    حاضنة طاقات غزة
                </div>
            </td>
            <td style="width: 40%; text-align: center;">
                <img src="{{ public_path('assets/logo.svg') }}" style="max-height: 60px;" />
            </td>
            <td style="width: 30%; text-align: center;">
                <div style="font-size: 14px; font-weight: bold;">
                    State of Palestine<br>
                    Taqat Gaza Incubator
                </div>
            </td>
        </tr>
    </table>
    <hr style="border: 1px solid #000; margin: 5px 0;" />
</div>
