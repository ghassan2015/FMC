<div style="position: fixed; bottom: 10px; left: 0; width: 100%; z-index: 999;">
            <table id="calender_tab" class="table" style="border-width:0; text-align: center; width: 100%;">
                <tr style="border-width:0;">
                    <td style="border-width:0; text-align: right; font-family:\'XBRiyaz\',serif;"></td>
                    <td style="border-width:0; text-align:right; font-family:\'XBRiyaz\',serif;"></td>
                </tr>
                <tr style="border-width:0;">
                    <td style="border-width:0; text-align: right;">
                        E-mail: info@taqat-gaza.com
                    </td>
                    <td style="border-width:0; text-align: center; font-family:\'XBRiyaz\',serif;">
                        شريف نعيم
                    </td>
                    <td style="border-width:0; text-align: left;">
                        Mobile: 0599-999-999
                    </td>
                </tr>
            </table>
        </div>
