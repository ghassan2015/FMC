<a href="javascript:void(0);" class="show-photo-modal" data-photo="{{ $data->photo }}">
                    <img src="{{ $data->photo }}" class="circle" style="object-fit:contain;width:70px;height:70px;border-radius: 50%;">
                </a>
