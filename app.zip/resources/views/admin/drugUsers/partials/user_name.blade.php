<a target="_blank" href="{{route('admin.users.views', $data->user_id)}}">{{$data->users?->name}}</a>
